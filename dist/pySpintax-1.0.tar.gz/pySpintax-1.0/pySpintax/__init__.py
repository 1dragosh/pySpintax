# -*- coding: utf-8 -*-

# Author: 1dragosh

from pySpintax.pySpintax import spin

name = 'pySpintax'
